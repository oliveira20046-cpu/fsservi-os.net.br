
import React from 'react';
import { Logo } from './components/Logo';
import Testimonials from './components/Testimonials';
import { 
  Network, 
  Settings, 
  ShieldCheck, 
  Zap, 
  Server, 
  Construction,
  CheckCircle2,
  Mail,
  Phone,
  MapPin,
  ChevronRight,
  Globe,
  MessageCircle,
  Instagram
} from 'lucide-react';

const App: React.FC = () => {
  const contactPhone = "(94) 992646042";
  const contactEmail = "oliveira20046@gmail.com";
  const contactInstagram = "fs_servicos_telecom";
  const whatsappLink = "https://wa.me/5594992646042";
  const instagramLink = `https://instagram.com/${contactInstagram}`;

  const cities = [
    "Pau D'arco - PA",
    "Redenção - PA",
    "Santa Maria das Barreiras - PA",
    "Santana do Araguaia - PA",
    "Vila Rica - MT",
    "Confresa - MT"
  ];

  const services = [
    {
      title: "PROJETOS DE REDES OPTICA FTTH",
      description: "Planejamento, instalação e otimização de redes de fibra óptica até a residência. Foco em tecnologias GPON e EPON para garantir ultra velocidade e estabilidade inabalável de sinal.",
      items: ["Planejamento Estratégico", "Instalação Técnica", "Otimização de Sinal", "Redes GPON e EPON"],
      icon: <Zap className="w-10 h-10 text-gold" />
    },
    {
      title: "PROJETOS DE REDE OPTICA FTTX",
      description: "Infraestrutura robusta para Backbone e criação de rotas estratégicas. Implementação de conexões Ponto a Ponto de alta performance para interligação de unidades.",
      items: ["Backbone de Fibra", "Criação de Rotas", "Ponto a Ponto (PTP)", "Alta Disponibilidade"],
      icon: <Network className="w-10 h-10 text-gold" />
    },
    {
      title: "REDES EMPRESARIAIS",
      description: "Consultoria completa em TI: da implementação e criação da topologia até a distribuição lógica, configuração de switches e gerência proativa da rede.",
      items: ["Implementação e Criação", "Distribuição de Carga", "Configuração Lógica", "Gerência de Tráfego"],
      icon: <Server className="w-10 h-10 text-gold" />
    },
    {
      title: "CABEAMENTO ESTRUTURADO",
      description: "Reorganização de redes existentes com foco em eficiência. Dimensionamento preciso para futuras expansões e organização rigorosa de racks de distribuição.",
      items: ["Reorganização de Redes", "Dimensionamento de Pontos", "Organização de Racks", "Certificação de Cabos"],
      icon: <Construction className="w-10 h-10 text-gold" />
    },
    {
      title: "CONFIGURAÇÕES ESPECIALIZADAS",
      description: "Expertise técnica avançada em equipamentos líderes de mercado. Configuração otimizada para máxima performance e segurança dos seus ativos de rede.",
      items: ["MikroTik", "UniFi (Ubiquiti)", "TP-Link", "Intelbras"],
      icon: <Settings className="w-10 h-10 text-gold" />
    },
    {
      title: "CFTV E SEGURANÇA",
      description: "Sistemas inteligentes de monitoramento. Instalação de câmeras IP e analógicas (Intelbras, Hikvision) com planos de manutenção preventiva e corretiva.",
      items: ["Instalação de Câmeras", "Configuração de DVR/NVR", "Manutenção Corretiva", "Intelbras & Hikvision"],
      icon: <ShieldCheck className="w-10 h-10 text-gold" />
    }
  ];

  return (
    <div className="min-h-screen text-white selection:bg-gold selection:text-fs-dark">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-fs-dark/90 backdrop-blur-md border-b border-gold/10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Logo className="h-10 w-10" hideText={true} />
            <div className="hidden sm:block">
              <span className="text-xl font-bold font-display text-gold tracking-tighter">FS SERVIÇOS</span>
              <p className="text-[8px] tracking-widest text-gold/80">TELECOMUNICAÇÕES</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium">
            <a href="#home" className="hover:text-gold transition-colors">Início</a>
            <a href="#servicos" className="hover:text-gold transition-colors">Serviços</a>
            <a href="#contato" className="hover:text-gold transition-colors">Contato</a>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="gold-gradient text-fs-dark px-5 py-2 rounded-full font-bold hover:shadow-[0_0_15px_rgba(212,175,55,0.4)] transition-all flex items-center gap-2">
              <MessageCircle className="w-4 h-4" /> Orçamento
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-fs-dark/80 via-fs-dark/40 to-fs-dark z-10" />
          <img 
            src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1920" 
            className="w-full h-full object-cover opacity-30 grayscale"
            alt="Infraestrutura Global de Telecomunicações"
          />
        </div>
        
        <div className="relative z-20 text-center px-6 max-w-4xl">
          <div className="mb-8 inline-block animate-bounce">
             <Logo className="h-32 w-32" hideText={true} />
          </div>
          <h2 className="text-gold text-sm md:text-lg font-bold tracking-[0.3em] uppercase mb-4 animate-fade-in">Serviços em Telecomunicações</h2>
          <h1 className="text-5xl md:text-8xl font-bold font-display leading-tight mb-6">
            Conectividade <br/> 
            <span className="text-gold italic">Sem Fronteiras.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl mx-auto leading-relaxed">
            Especialistas em projetos de redes ópticas, infraestrutura empresarial e configurações de alta performance com anos de excelência técnica.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#servicos" className="w-full sm:w-auto gold-gradient text-fs-dark px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-all shadow-xl">
              Ver Serviços
            </a>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto border border-gold/50 text-gold px-10 py-4 rounded-full font-bold text-lg hover:bg-gold/10 transition-all backdrop-blur-sm flex items-center justify-center gap-2">
              <MessageCircle className="w-5 h-5" /> Fale Conosco
            </a>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-gold/5 border-y border-gold/10">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { label: "Projetos Entregues", val: "100+" },
            { label: "Cidades Atendidas", val: "Todo País" },
            { label: "Suporte Especializado", val: "100%" },
            { label: "Anos de Mercado", val: "4" }
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <p className="text-gold text-3xl font-bold mb-1">{stat.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Cities Section */}
      <section className="py-16 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-8 justify-between">
            <div className="flex items-center gap-4">
              <Globe className="w-10 h-10 text-gold" />
              <div>
                <h4 className="text-xl font-bold">Nossa Atuação</h4>
                <p className="text-white/40 text-sm">Prontos para atender em todo o território nacional</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-3 justify-center">
              {cities.map((city, i) => (
                <span key={i} className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-xs font-medium hover:border-gold/30 transition-colors">
                  {city}
                </span>
              ))}
              <span className="px-4 py-2 bg-gold/10 border border-gold/30 rounded-full text-xs font-bold text-gold">
                + Atendimento em Todo o País
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicos" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-gold font-bold uppercase tracking-[0.2em] mb-4">Portfólio de Atuação</h2>
            <h3 className="text-4xl md:text-5xl font-display font-bold">Soluções de Engenharia</h3>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, idx) => (
              <div 
                key={idx} 
                className="group relative bg-white/5 border border-white/10 rounded-[40px] p-10 hover:border-gold/50 transition-all hover:translate-y-[-8px] duration-500 flex flex-col items-start"
              >
                <div className="mb-8 p-4 bg-gold/10 rounded-2xl border border-gold/20 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                
                <h4 className="text-xl font-bold mb-4 group-hover:text-gold transition-colors">{service.title}</h4>
                <p className="text-white/60 text-sm mb-8 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-3 mb-8 w-full">
                  {service.items.map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-white/60 group-hover:text-white/80 transition-colors">
                      <CheckCircle2 className="w-4 h-4 text-gold flex-shrink-0" />
                      <span className="text-sm font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-auto w-full pt-6 border-t border-white/5 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-all">
                  <span className="text-[10px] text-gold uppercase tracking-[0.2em] font-bold">Solicitar Proposta</span>
                  <ChevronRight className="w-4 h-4 text-gold" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />

      {/* Partners/Brands Section */}
      <section className="py-20 px-6 bg-black/40">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-white/40 text-sm uppercase tracking-widest mb-10">Equipamentos e Parceiros</p>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-50 grayscale hover:grayscale-0 transition-all">
            <span className="text-2xl font-bold italic text-white">MikroTik</span>
            <span className="text-2xl font-bold italic text-white">Ubiquiti / UniFi</span>
            <span className="text-2xl font-bold italic text-white">TP-Link</span>
            <span className="text-2xl font-bold italic text-white">Intelbras</span>
            <span className="text-2xl font-bold italic text-white">Hikvision</span>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div className="space-y-10">
              <div>
                <h2 className="text-gold font-bold uppercase tracking-[0.2em] mb-4">Contato</h2>
                <h3 className="text-5xl font-display font-bold mb-6">Sua rede em boas mãos.</h3>
                <p className="text-white/60 text-lg">Projetamos o futuro da sua conectividade com rigor técnico e as melhores marcas do mundo.</p>
              </div>

              <div className="space-y-6">
                <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-start gap-6 group">
                  <div className="w-12 h-12 gold-gradient flex items-center justify-center rounded-2xl text-fs-dark group-hover:scale-110 transition-transform">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">Telefone & WhatsApp</h5>
                    <p className="text-white/60 group-hover:text-gold transition-colors">{contactPhone}</p>
                  </div>
                </a>
                <a href={instagramLink} target="_blank" rel="noopener noreferrer" className="flex items-start gap-6 group">
                  <div className="w-12 h-12 gold-gradient flex items-center justify-center rounded-2xl text-fs-dark group-hover:scale-110 transition-transform">
                    <Instagram className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">Instagram</h5>
                    <p className="text-white/60 group-hover:text-gold transition-colors">@{contactInstagram}</p>
                  </div>
                </a>
                <a href={`mailto:${contactEmail}`} className="flex items-start gap-6 group">
                  <div className="w-12 h-12 gold-gradient flex items-center justify-center rounded-2xl text-fs-dark group-hover:scale-110 transition-transform">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">E-mail Corporativo</h5>
                    <p className="text-white/60 group-hover:text-gold transition-colors">{contactEmail}</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="bg-white/5 p-10 rounded-[40px] border border-white/10 shadow-2xl backdrop-blur-xl">
              <form className="space-y-6" onSubmit={(e) => {
                e.preventDefault();
                window.open(whatsappLink, '_blank');
              }}>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gold font-bold">Seu Nome</label>
                    <input type="text" className="w-full bg-black/20 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-gold transition-colors text-white" placeholder="Nome completo" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gold font-bold">Cidade</label>
                    <input type="text" className="w-full bg-black/20 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-gold transition-colors text-white" placeholder="Sua cidade" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-gold font-bold">Serviço</label>
                  <select className="w-full bg-black/20 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-gold transition-colors appearance-none text-white">
                    <option className="bg-fs-dark">FTTH / GPON</option>
                    <option className="bg-fs-dark">Redes Empresariais</option>
                    <option className="bg-fs-dark">Cabeamento Estruturado</option>
                    <option className="bg-fs-dark">CFTV / Segurança</option>
                  </select>
                </div>
                <button type="submit" className="w-full gold-gradient text-fs-dark font-bold py-5 rounded-2xl text-lg hover:shadow-[0_10px_30px_rgba(212,175,55,0.3)] transition-all flex items-center justify-center gap-2">
                  <MessageCircle className="w-6 h-6" /> Solicitar Orçamento via WhatsApp
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 bg-black">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="flex items-center gap-4">
            <Logo className="h-12 w-12" hideText={true} />
            <div>
              <h4 className="text-xl font-bold font-display text-gold">FS SERVIÇOS</h4>
              <p className="text-[10px] tracking-[0.2em] uppercase text-white/40">Excelência em Telecomunicações</p>
            </div>
          </div>
          <div className="flex gap-6">
            <a href={instagramLink} target="_blank" rel="noopener noreferrer" className="text-white/40 hover:text-gold transition-colors">
              <Instagram className="w-6 h-6" />
            </a>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="text-white/40 hover:text-gold transition-colors">
              <MessageCircle className="w-6 h-6" />
            </a>
          </div>
          <p className="text-white/20 text-sm">
            © 2021 FS Serviços. Atendendo Todo Pais!
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
