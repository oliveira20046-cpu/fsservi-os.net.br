
// Fix: Import React to resolve the 'Cannot find namespace React' error on line 5
import React from 'react';

export interface ServiceItem {
  title: string;
  items: string[];
  icon: React.ReactNode;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}