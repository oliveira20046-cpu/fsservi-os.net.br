
import React, { useState } from 'react';
import { Quote, Send, User, MessageSquare, Star } from 'lucide-react';

interface Opinion {
  name: string;
  service: string;
  text: string;
  date: string;
}

const Testimonials: React.FC = () => {
  const [opinions, setOpinions] = useState<Opinion[]>([]);
  const [formData, setFormData] = useState({ name: '', service: '', text: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.text) return;

    const newOpinion: Opinion = {
      ...formData,
      date: new Date().toLocaleDateString('pt-BR'),
      service: formData.service || 'Serviço Geral'
    };

    setOpinions([newOpinion, ...opinions]);
    setFormData({ name: '', service: '', text: '' });
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section className="py-32 px-6 bg-gold/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-gold font-bold uppercase tracking-[0.2em] mb-4">Espaço do Cliente</h2>
          <h3 className="text-4xl md:text-5xl font-display font-bold mb-6">Sua opinião é fundamental</h3>
          <p className="text-white/60 max-w-2xl mx-auto">
            Trabalhamos para conectar pessoas e empresas. Se você já utilizou nossos serviços, compartilhe sua experiência com outros clientes.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          {/* Form Side */}
          <div className="lg:col-span-5">
            <div className="bg-fs-dark p-8 rounded-[32px] border border-gold/20 shadow-2xl">
              <h4 className="text-xl font-bold mb-6 flex items-center gap-2">
                <MessageSquare className="text-gold w-5 h-5" />
                Deixe seu depoimento
              </h4>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-gold font-bold mb-2 block">Nome Completo</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gold/50" />
                    <input 
                      type="text" 
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Como deseja ser identificado?"
                      className="w-full bg-black/40 border border-white/10 rounded-xl pl-12 pr-4 py-3 text-sm focus:outline-none focus:border-gold transition-colors"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-gold font-bold mb-2 block">Serviço Realizado</label>
                  <select 
                    value={formData.service}
                    onChange={(e) => setFormData({...formData, service: e.target.value})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-gold transition-colors appearance-none text-white/70"
                  >
                    <option value="">Selecione o serviço</option>
                    <option value="FTTH / Fibra Óptica">FTTH / Fibra Óptica</option>
                    <option value="Rede Empresarial">Rede Empresarial</option>
                    <option value="Cabeamento Estruturado">Cabeamento Estruturado</option>
                    <option value="Configuração Mikrotik/Ubiquiti">Configuração Mikrotik/Ubiquiti</option>
                    <option value="CFTV / Segurança">CFTV / Segurança</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-gold font-bold mb-2 block">Sua Mensagem</label>
                  <textarea 
                    value={formData.text}
                    onChange={(e) => setFormData({...formData, text: e.target.value})}
                    placeholder="Conte como foi nossa prestação de serviço..."
                    rows={4}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-gold transition-colors resize-none"
                    required
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full gold-gradient text-fs-dark font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all group"
                >
                  {submitted ? 'Enviado com Sucesso!' : 'Publicar Opinião'}
                  <Send className={`w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform ${submitted ? 'hidden' : ''}`} />
                </button>
              </form>
            </div>
          </div>

          {/* Opinions Display Side */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xl font-bold font-display">Opiniões Recentes</h4>
              <span className="text-xs text-gold/60 uppercase tracking-widest font-bold">
                {opinions.length} Comentários
              </span>
            </div>

            {opinions.length === 0 ? (
              <div className="bg-white/5 border border-dashed border-white/10 rounded-[32px] p-12 text-center">
                <Quote className="w-12 h-12 text-gold/10 mx-auto mb-4" />
                <p className="text-white/40 italic">Ainda não há depoimentos publicados hoje. <br/> Seja o primeiro a deixar sua opinião!</p>
              </div>
            ) : (
              <div className="grid gap-6 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                {opinions.map((op, i) => (
                  <div key={i} className="bg-fs-dark p-6 rounded-[24px] border border-white/5 hover:border-gold/20 transition-all relative group animate-fade-in">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold font-bold border border-gold/20">
                          {op.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h5 className="text-white font-bold text-sm">{op.name}</h5>
                          <p className="text-gold/60 text-[10px] uppercase tracking-tighter">{op.service}</p>
                        </div>
                      </div>
                      <span className="text-[10px] text-white/30">{op.date}</span>
                    </div>
                    <p className="text-white/70 text-sm italic leading-relaxed">
                      "{op.text}"
                    </p>
                    <div className="mt-4 flex gap-1">
                      {[1,2,3,4,5].map(s => <Star key={s} className="w-3 h-3 text-gold fill-gold" />)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Background Decorative Element */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gold/5 rounded-full blur-[120px] pointer-events-none" />
    </section>
  );
};

export default Testimonials;
