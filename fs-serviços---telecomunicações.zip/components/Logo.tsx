
import React from 'react';

export const Logo: React.FC<{ className?: string, hideText?: boolean }> = ({ className = "h-16 w-16", hideText = false }) => {
  return (
    <div className={`flex flex-col items-center ${hideText ? '' : 'gap-2'}`}>
      <svg 
        viewBox="0 0 100 100" 
        className={className}
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Tower Structure */}
        <path 
          d="M50 15 L35 90 M50 15 L65 90 M40 40 L60 40 M38 60 L62 60 M36 80 L64 80" 
          stroke="#d4af37" 
          strokeWidth="3" 
          strokeLinecap="round"
        />
        {/* Tower Crossbars */}
        <path d="M42 30 L58 30 M35 90 L65 90" stroke="#d4af37" strokeWidth="3" />
        <path d="M50 15 L50 10" stroke="#d4af37" strokeWidth="4" strokeLinecap="round" />
        <circle cx="50" cy="15" r="4" fill="#d4af37" />
        
        {/* Signal Waves Left */}
        <path d="M35 15 Q25 15 25 5 M35 25 Q15 25 15 5 M35 35 Q5 35 5 5" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" className="opacity-70" />
        <path d="M28 15 C20 10 20 20 28 15" stroke="#d4af37" strokeWidth="2" fill="none" />
        
        {/* Signal Waves (Standard simplified style) */}
        <path d="M38 15 A12 12 0 0 0 38 15 M30 15 A20 20 0 0 0 30 15" stroke="#d4af37" strokeWidth="2" />
        
        {/* Hand-drawn style waves based on reference image */}
        <path d="M38 12 Q33 15 38 18" stroke="#d4af37" strokeWidth="2.5" fill="none" />
        <path d="M33 8 Q25 15 33 22" stroke="#d4af37" strokeWidth="2.5" fill="none" />
        
        <path d="M62 12 Q67 15 62 18" stroke="#d4af37" strokeWidth="2.5" fill="none" />
        <path d="M67 8 Q75 15 67 22" stroke="#d4af37" strokeWidth="2.5" fill="none" />
      </svg>
      {!hideText && (
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tighter text-gold font-display leading-none">FS SERVIÇOS</h1>
          <p className="text-[10px] uppercase tracking-widest text-gold opacity-80 mt-1">SERVIÇOS EM TELECOMUNICAÇÕES</p>
        </div>
      )}
    </div>
  );
};
