import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from '../types';

const GeminiConsultant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Fix: Create a new GoogleGenAI instance right before making an API call and upgrade model to 'gemini-3-pro-preview' for technical STEM-related tasks
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: input,
        config: {
          systemInstruction: `Você é um consultor sênior de engenharia de telecomunicações da empresa FS Serviços. 
          Seu objetivo é ajudar potenciais clientes com dúvidas técnicas sobre:
          - Projetos de Redes Óptica FTTH (GPON/EPON)
          - FTTX (Backbone, rotas)
          - Redes Empresariais
          - Cabeamento Estruturado
          - Configurações (Mikrotik, Ubiquiti/UniFi, TP-Link, Intelbras)
          - CFTV
          
          Responda de forma profissional, educada e técnica em Português do Brasil. Sempre recomende que para uma análise detalhada, o cliente deve entrar em contato com a equipe da FS Serviços.`,
        }
      });

      // Fix: Correctly access text from GenerateContentResponse using the .text property
      const aiText = response.text || "Desculpe, não consegui processar sua dúvida no momento.";
      setMessages(prev => [...prev, { role: 'model', text: aiText }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Ocorreu um erro ao conectar com nosso assistente técnico. Por favor, tente novamente mais tarde." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="consultoria" className="py-20 px-6 bg-[#3d2b1f]">
      <div className="max-w-4xl mx-auto bg-fs-dark border border-gold/30 rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-gold/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full gold-gradient flex items-center justify-center text-fs-dark font-bold">FS</div>
            <div>
              <h3 className="text-white font-semibold">Consultoria Técnica IA</h3>
              <p className="text-gold/60 text-xs">Assistente Virtual FS Serviços</p>
            </div>
          </div>
        </div>

        <div 
          ref={scrollRef}
          className="h-[400px] overflow-y-auto p-6 space-y-4 bg-black/20"
        >
          {messages.length === 0 && (
            <div className="text-center py-10 opacity-50 space-y-2">
              <p className="text-white">Olá! Como posso ajudar com sua infraestrutura de rede hoje?</p>
              <p className="text-xs text-gold">Tire dúvidas sobre projetos de fibra, configurações Mikrotik ou segurança.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-4 rounded-2xl text-sm ${
                m.role === 'user' 
                ? 'bg-gold text-fs-dark rounded-tr-none' 
                : 'bg-white/10 text-white border border-white/10 rounded-tl-none'
              }`}>
                {m.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white/10 text-white p-4 rounded-2xl rounded-tl-none animate-pulse">
                Analisando infraestrutura...
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-fs-dark border-t border-gold/20">
          <div className="flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ex: Qual a vantagem do GPON sobre EPON?"
              className="flex-1 bg-black/40 border border-gold/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading}
              className="gold-gradient text-fs-dark px-6 py-3 rounded-xl font-bold hover:scale-105 transition-transform disabled:opacity-50"
            >
              Enviar
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GeminiConsultant;